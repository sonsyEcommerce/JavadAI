package com.javadai.agent.execution;

import com.javadai.agent.workspace.WorkspaceManager;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/** Runs a small, fixed set of project checks. No user-provided shell command is accepted. */
@Component
public class ProjectExecutionTool {
    private static final Duration TIMEOUT = Duration.ofMinutes(5);
    private static final int OUTPUT_LIMIT = 30_000;
    private final WorkspaceManager workspace;

    public ProjectExecutionTool(WorkspaceManager workspace) {
        this.workspace = workspace;
    }

    public ExecutionResult execute(String projectPath, String check) {
        long started = System.nanoTime();
        try {
            Path project = resolveProject(projectPath);
            String kind = detect(project);
            String action = check == null ? "build" : check.trim().toLowerCase(Locale.ROOT);
            List<String> command = command(project, kind, action);
            Process process = new ProcessBuilder(command).directory(project.toFile())
                    .redirectErrorStream(true).start();
            CompletableFuture<String> output = CompletableFuture.supplyAsync(() -> readOutput(process));
            boolean ended = process.waitFor(TIMEOUT.toMillis(), TimeUnit.MILLISECONDS);
            if (!ended) {
                process.destroy();
                if (!process.waitFor(2, TimeUnit.SECONDS)) process.destroyForcibly();
                return result(false, true, null, output.get(5, TimeUnit.SECONDS), started);
            }
            String text = output.get(10, TimeUnit.SECONDS);
            return result(process.exitValue() == 0, false, process.exitValue(), text, started);
        } catch (Exception e) {
            return result(false, false, -1, "Execution failed: " + e.getMessage(), started);
        }
    }

    private Path resolveProject(String relative) throws IOException {
        Path root = workspace.getRoot();
        Path candidate = root.resolve(relative == null ? "" : relative).normalize();
        if (!candidate.startsWith(root)) throw new SecurityException("Project path is outside workspace.");
        Path real = candidate.toRealPath();
        if (!real.startsWith(root) || !Files.isDirectory(real)) throw new SecurityException("Invalid project directory.");
        return real;
    }

    private String detect(Path project) {
        if (Files.isRegularFile(project.resolve("pom.xml"))) return "maven";
        if (Files.isRegularFile(project.resolve("package.json"))
                && Files.isRegularFile(project.resolve("angular.json"))) return "angular";
        throw new IllegalArgumentException("No supported project found. Expected pom.xml or Angular package.json + angular.json.");
    }

    private List<String> command(Path project, String kind, String action) {
        if (!action.equals("build") && !action.equals("test"))
            throw new IllegalArgumentException("Supported checks are build and test.");
        List<String> cmd = new ArrayList<>();
        boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
        if (kind.equals("maven")) {
            Path wrapper = project.resolve(windows ? "mvnw.cmd" : "mvnw");
            if (Files.isRegularFile(wrapper)) {
                if (windows) { cmd.add("cmd.exe"); cmd.add("/c"); cmd.add(wrapper.toAbsolutePath().toString()); }
                else { cmd.add("sh"); cmd.add(wrapper.toAbsolutePath().toString()); }
            } else cmd.add(windows ? "mvn.cmd" : "mvn");
            cmd.add(action.equals("test") ? "test" : "-DskipTests");
            if (action.equals("build")) cmd.add("package");
        } else {
            cmd.add(windows ? "npm.cmd" : "npm");
            if (action.equals("build")) { cmd.add("run"); cmd.add("build"); }
            else { cmd.add("exec"); cmd.add("ng"); cmd.add("test"); cmd.add("--"); cmd.add("--watch=false"); }
        }
        return cmd;
    }

    private String readOutput(Process process) {
        try (var in = process.getInputStream(); var out = new java.io.ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            int stored = 0;
            boolean truncated = false;
            while ((count = in.read(buffer)) != -1) {
                int keep = Math.min(count, OUTPUT_LIMIT - stored);
                if (keep > 0) { out.write(buffer, 0, keep); stored += keep; }
                if (keep < count) truncated = true;
            }
            String value = out.toString(StandardCharsets.UTF_8);
            return truncated ? value + "\n...[output truncated]" : value;
        } catch (IOException e) { return "Unable to read process output: " + e.getMessage(); }
    }

    private ExecutionResult result(boolean ok, boolean timeout, Integer exit, String output, long started) {
        return new ExecutionResult(ok, timeout, exit, output, "", Duration.ofNanos(System.nanoTime() - started));
    }
}
