# JavadAI — Quick start

## What this version does

- Uses the Ollama model configured by `OLLAMA_MODEL` (default: `qwen2.5-coder:7b`).
- Lets the agent inspect workspace files and propose code changes.
- Adds bounded Maven and Angular build/test execution inside the configured workspace.
- Does not accept arbitrary shell commands through the project-check tool.
- Supports Windows and Linux command launchers.

> JavadAI is an AI agent application powered by an existing model. It does not train a new foundation model. Fine-tuning or training a model is a separate later project.

## 1. Install prerequisites

- Java 21+
- PostgreSQL
- Ollama
- Node.js + npm (for Angular projects)
- Maven is optional when a Maven Wrapper (`mvnw` / `mvnw.cmd`) exists

## 2. Pull and start the local model

```bash
ollama pull qwen2.5-coder:7b
ollama serve
```

## 3. Configure backend environment

Set these environment variables before starting Spring Boot:

```text
DB_URL=jdbc:postgresql://localhost:5432/javadai
DB_USERNAME=javadai_user
DB_PASSWORD=<your-local-postgresql-password>
JAVADAI_WORKSPACE=<absolute-path-to-your-project-workspace>
OLLAMA_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5-coder:7b
```

The PostgreSQL database and user must already exist. Do not commit real passwords to source control.

## 4. Start backend

From `backend`:

Windows:
```powershell
$env:DB_PASSWORD="your-password"
.\mvnw.cmd spring-boot:run
```

Linux:
```bash
export DB_PASSWORD='your-password'
sh ./mvnw spring-boot:run
```

## 5. Start frontend

From `frontend`:

```bash
npm install
npm start
```

## 6. Ask JavadAI to check a project

Examples:

- `پروژه را بررسی کن و ساختار آن را توضیح بده`
- `پروژه Maven را build کن`
- `تست‌های پروژه را اجرا کن`
- `پروژه Angular را build کن`

Project build/test execution is limited to projects located inside `JAVADAI_WORKSPACE` and to the supported fixed commands.
